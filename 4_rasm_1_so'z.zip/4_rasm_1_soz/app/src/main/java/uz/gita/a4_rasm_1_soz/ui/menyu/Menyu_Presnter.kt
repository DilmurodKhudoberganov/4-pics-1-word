package uz.gita.a4_rasm_1_soz.ui.menyu

import uz.gita.a4_rasm_1_soz.ui.main.MainActivity

class Menyu_Presnter(private val view: Contrak.View) : Contrak.Presenter {

    override fun clickRandomButton() {
        view.openMainActviyt()
    }

    override fun clickAboutButton() {
        view.openAbout()
    }
}