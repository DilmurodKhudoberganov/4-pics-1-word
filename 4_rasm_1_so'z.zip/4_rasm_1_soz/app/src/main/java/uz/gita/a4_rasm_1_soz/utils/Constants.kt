package uz.gita.a4_rasm_1_soz.utils

object Constants {

    val WIN_COIN = 20
    val HINT_COIN = 0
    val DEFAULT_COIN = 100

}