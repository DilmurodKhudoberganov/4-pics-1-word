package uz.gita.a4_rasm_1_soz.ui.menyu

interface Contrak {

    interface View {
        fun openMainActviyt()
        fun openAbout()
    }

    interface Presenter {
        fun clickRandomButton()
        fun clickAboutButton()
    }
}