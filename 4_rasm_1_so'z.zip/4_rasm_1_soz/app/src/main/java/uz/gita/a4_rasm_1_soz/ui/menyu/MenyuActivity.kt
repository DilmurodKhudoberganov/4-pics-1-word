package uz.gita.a4_rasm_1_soz.ui.menyu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import uz.gita.a4_rasm_1_soz.R
import uz.gita.a4_rasm_1_soz.databinding.ActivityMenyuBinding
import uz.gita.a4_rasm_1_soz.ui.about.AboutActivity
import uz.gita.a4_rasm_1_soz.ui.main.MainActivity
import uz.gita.a4_rasm_1_soz.ui.menyu.Contrak.Presenter

class MenyuActivity : AppCompatActivity(), Contrak.View {
    private lateinit var binding: ActivityMenyuBinding

    private lateinit var presnter: Presenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMenyuBinding.inflate(layoutInflater)
        setContentView(binding.root)
        presnter = Menyu_Presnter(this)

        binding.apply {
            btnStart.setOnClickListener { presnter.clickRandomButton() }
            btnAbout.setOnClickListener { presnter.clickAboutButton() }
            btnQuit.setOnClickListener { finishAffinity() }
        }
    }

    override fun openMainActviyt() {
        startActivity(Intent(this, MainActivity::class.java))
    }

    override fun openAbout() {
        startActivity(Intent(this, AboutActivity::class.java))
    }
}