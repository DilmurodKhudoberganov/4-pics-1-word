package uz.gita.a4_rasm_1_soz.ui.main

import uz.gita.a4_rasm_1_soz.model.QuestionData

interface Main_Contarak {

    interface View {
        fun wrongAnsAnimation()
        fun showHint()
        fun setCoin()
        fun closeScreen()
        fun showToast()
        fun describeQuestionData(data: QuestionData, currentPos: Int, total: Int)
        fun showAnswer(value: String, index: Int)
        fun getFirstEmptyPos(): Int
        fun openResultActivity()
    }
    interface Presnrter {
        fun hint(coin: Int)
        fun getCoin(): Int
        fun addCoin(coin: Int)
        fun divideCoin(coin: Int)
        fun showExitDialog()
        fun showWinDialog()
        fun checkAnswer(userAnswer: String)
        fun loadNextQuestion()
        fun clickVariantButton(value: String)
    }
    interface Model {
        fun getCurrentPos(): Int
        fun getTotal(): Int
        fun nextQuestionData(): QuestionData
        fun isLastQuestion(): Boolean
        fun checkAnswer(userAnswer: String): Boolean

    }


}