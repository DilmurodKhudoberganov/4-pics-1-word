package uz.gita.a4_rasm_1_soz.ui.main

import uz.gita.a4_rasm_1_soz.model.QuestionData
import uz.gita.a4_rasm_1_soz.repository.AppRepository_2

class MainModel : Main_Contarak.Model {
    private val repository = AppRepository_2.getINstence()
    private val list = ArrayList<QuestionData>()
    private var currentPos = 0
    private val max = 40

    init {
        list.addAll(repository.getAll())
    }


    override fun getCurrentPos() = currentPos

    override fun getTotal() = max

    override fun nextQuestionData() = list[currentPos++]


    override fun isLastQuestion() = currentPos < max


    override fun checkAnswer(userAnswer: String) = userAnswer == list[currentPos - 1].answer
}
